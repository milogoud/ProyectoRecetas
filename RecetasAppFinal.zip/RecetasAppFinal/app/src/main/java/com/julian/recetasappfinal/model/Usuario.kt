package com.julian.recetasappfinal.model

data class Usuario(
    var id: String? = null,
    var usuario: String? = null,
    var password: String? = null
)